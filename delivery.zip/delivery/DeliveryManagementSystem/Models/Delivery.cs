namespace DeliveryManagementSystem.Models
{
    public class Delivery
    {
        public int DeliveryId { get; set; }
        public string OrderInfo { get; set; }
        public string CourierName { get; set; }
        public string DeliveryDate { get; set; }
        public string DeliveryStatus { get; set; }
    }
}
