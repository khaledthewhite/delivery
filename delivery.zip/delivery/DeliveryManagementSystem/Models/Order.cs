namespace DeliveryManagementSystem.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public string CustomerName { get; set; }
        public string OrderDate { get; set; }
        public string PickupLocation { get; set; }
        public string DeliveryLocation { get; set; }
        public decimal Cost { get; set; }
        public string Status { get; set; }
    }
}
