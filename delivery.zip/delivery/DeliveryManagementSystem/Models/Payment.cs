namespace DeliveryManagementSystem.Models
{
    public class Payment
    {
        public int PaymentId { get; set; }
        public string OrderInfo { get; set; }
        public string PaymentDate { get; set; }
        public decimal Amount { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentStatus { get; set; }
    }
}
