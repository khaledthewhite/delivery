namespace DeliveryManagementSystem.Models
{
    public class Courier
    {
        public int CourierId { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string VehicleType { get; set; }
        public string LicenseNumber { get; set; }
        public string AvailabilityStatus { get; set; }
    }
}
