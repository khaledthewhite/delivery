CREATE DATABASE DeliveryDB;
GO

USE DeliveryDB;
GO

CREATE TABLE customers (
    customer_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    phone NVARCHAR(20),
    address NVARCHAR(MAX),
    email NVARCHAR(100)
);

CREATE TABLE couriers (
    courier_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    phone NVARCHAR(20),
    vehicle_type NVARCHAR(50),
    license_number NVARCHAR(50),
    availability_status NVARCHAR(20)
);

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_name NVARCHAR(100),
    order_date NVARCHAR(20),
    pickup_location NVARCHAR(MAX),
    delivery_location NVARCHAR(MAX),
    cost DECIMAL(10,2),
    status NVARCHAR(50)
);

CREATE TABLE deliveries (
    delivery_id INT IDENTITY(1,1) PRIMARY KEY,
    order_info NVARCHAR(100),
    courier_name NVARCHAR(100),
    delivery_date NVARCHAR(30),
    delivery_status NVARCHAR(50)
);

CREATE TABLE payments (
    payment_id INT IDENTITY(1,1) PRIMARY KEY,
    order_info NVARCHAR(100),
    payment_date NVARCHAR(30),
    amount DECIMAL(10,2),
    payment_method NVARCHAR(50),
    payment_status NVARCHAR(50)
);

CREATE TABLE users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    full_name NVARCHAR(100) NOT NULL,
    username NVARCHAR(50) NOT NULL UNIQUE,
    password NVARCHAR(100) NOT NULL,
    role NVARCHAR(30) NOT NULL,
    status NVARCHAR(20) NOT NULL
);
GO

INSERT INTO customers (name, phone, address, email) VALUES 
(N'مؤسسة النور', N'012345678', N'شارع الستين - صنعاء', N'info@alnoor.example'),
(N'خالد عبدالله', N'733222111', N'مدينة حدة - صنعاء', NULL),
(N'سارة محمد', N'771987654', N'حي التحرير - صنعاء', N'sara@example.com'),
(N'أحمد علي', N'770123456', N'شارع الجامعة - صنعاء', N'ahmed@example.com');

INSERT INTO couriers (name, phone, vehicle_type, license_number, availability_status) VALUES 
(N'نبيل قاسم', N'777777888', N'فان صغير', N'LIC-1004', N'غير متاح'),
(N'عادل حسن', N'777555666', N'دراجة نارية', N'LIC-1003', N'متاح'),
(N'فؤاد صالح', N'777333444', N'سيارة صغيرة', N'LIC-1002', N'متاح'),
(N'مازن سعيد', N'777111222', N'دراجة نارية', N'LIC-1001', N'مشغول');

INSERT INTO orders
(order_id, customer_name, order_date, pickup_location, delivery_location, cost, status)
VALUES 
(1, N'أحمد علي', N'4/17/2026', N'مكتب الجامعة', N'شارع الجزائر', 1200.00, N'تم التسليم'),
(2, N'سارة محمد', N'4/18/2026', N'حدة', N'التحرير', 1500.00, N'قيد التنفيذ'),
(3, N'خالد عبد الله', N'4/19/2026', N'شارع الستين', N'باب اليمن', 1000.00, N'جديد'),
(4, N'مؤسسة النور', N'4/19/2026', N'مؤسسة النور', N'الجامعة الجديدة', 2000.00, N'ملغي'),
(5, N'أحمد علي', N'4/19/2026', N'حي الصافية', N'السنينة', 900.00, N'جديد');

INSERT INTO deliveries
(order_info, courier_name, delivery_date, delivery_status)
VALUES 
(N'طلب #1 - أحمد علي', N'فؤاد صالح', N'4/17/2026', N'تم التسليم'),
(N'طلب 2 - سارة محمد', N'مازن سعيد', N'4/18/2026', N'قيد التوصيل'),
(N'طلب 4 - مؤسسة النور', N'عادل حسن', N'4/19/2026', N'فشل التوصيل');

INSERT INTO payments
(order_info, payment_date, amount, payment_method, payment_status)
VALUES 
(N'طلب #1 - أحمد علي', N'4/17/2026', 1200.00, N'نقدي', N'مدفوع'),
(N'طلب 2 - سارة محمد', N'4/18/2026', 500.00, N'تحويل', N'جزئي'),
(N'طلب 3 - خالد عبد الله', N'4/19/2026', 0.00, N'نقدي', N'غير مدفوع'),
(N'طلب #4 - مؤسسة النور', N'4/19/2026', 0.00, N'إلكتروني', N'غير مدفوع');

INSERT INTO users
(full_name, username, password, role, status)
VALUES
(N'مدير النظام', N'admin', N'admin123', N'Admin', N'نشط'),
(N'موظف النظام', N'user1', N'1234', N'Staff', N'نشط');
