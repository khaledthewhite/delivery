using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DeliveryManagementSystem.Data;

namespace DeliveryManagementSystem.Forms
{
    public partial class FrmCouriers : Form
    {
        public FrmCouriers()
        {
            InitializeComponent();
        }

        private void FrmCouriers_Load(object sender, EventArgs e)
        {
            if (!this.DesignMode)
            {
                cmbAvailabilityStatus.SelectedIndex = 0;
                LoadData();
            }
        }

        private void LoadData()
        {
            try
            {
                string query = "SELECT courier_id AS [رقم المندوب], name AS [اسم المندوب], phone AS [رقم الهاتف], vehicle_type AS [نوع المركبة], license_number AS [رقم الرخصة], availability_status AS [الحالة] FROM couriers";
                dgvCouriers.DataSource = DatabaseHelper.ExecuteQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCourierName.Text))
            {
                MessageBox.Show("اسم المندوب مطلوب", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "INSERT INTO couriers (name, phone, vehicle_type, license_number, availability_status) VALUES (@Name, @Phone, @Vehicle, @License, @Status)";
                SqlParameter[] parameters = {
                    new SqlParameter("@Name", txtCourierName.Text),
                    new SqlParameter("@Phone", txtCourierPhone.Text),
                    new SqlParameter("@Vehicle", txtVehicleType.Text),
                    new SqlParameter("@License", txtLicenseNumber.Text),
                    new SqlParameter("@Status", cmbAvailabilityStatus.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCourierId.Text))
            {
                MessageBox.Show("الرجاء تحديد مندوب لتعديله", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "UPDATE couriers SET name=@Name, phone=@Phone, vehicle_type=@Vehicle, license_number=@License, availability_status=@Status WHERE courier_id=@Id";
                SqlParameter[] parameters = {
                    new SqlParameter("@Id", txtCourierId.Text),
                    new SqlParameter("@Name", txtCourierName.Text),
                    new SqlParameter("@Phone", txtCourierPhone.Text),
                    new SqlParameter("@Vehicle", txtVehicleType.Text),
                    new SqlParameter("@License", txtLicenseNumber.Text),
                    new SqlParameter("@Status", cmbAvailabilityStatus.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCourierId.Text))
            {
                MessageBox.Show("الرجاء تحديد مندوب لحذفه", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("هل أنت متأكد من حذف هذا السجل؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM couriers WHERE courier_id=@Id";
                    SqlParameter[] parameters = { new SqlParameter("@Id", txtCourierId.Text) };
                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                    btnClear_Click(null, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCourierId.Clear();
            txtCourierName.Clear();
            txtCourierPhone.Clear();
            txtVehicleType.Clear();
            txtLicenseNumber.Clear();
            cmbAvailabilityStatus.SelectedIndex = 0;
            txtSearchCourier.Clear();
            txtCourierName.Focus();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT courier_id AS [رقم المندوب], name AS [اسم المندوب], phone AS [رقم الهاتف], vehicle_type AS [نوع المركبة], license_number AS [رقم الرخصة], availability_status AS [الحالة] FROM couriers WHERE name LIKE @Search";
                SqlParameter[] parameters = { new SqlParameter("@Search", "%" + txtSearchCourier.Text + "%") };
                dgvCouriers.DataSource = DatabaseHelper.ExecuteQuery(query, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvCouriers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvCouriers.Rows[e.RowIndex];
                txtCourierId.Text = row.Cells["رقم المندوب"].Value.ToString();
                txtCourierName.Text = row.Cells["اسم المندوب"].Value.ToString();
                txtCourierPhone.Text = row.Cells["رقم الهاتف"].Value.ToString();
                txtVehicleType.Text = row.Cells["نوع المركبة"].Value.ToString();
                txtLicenseNumber.Text = row.Cells["رقم الرخصة"].Value.ToString();
                cmbAvailabilityStatus.Text = row.Cells["الحالة"].Value.ToString();
            }
        }
    }
}
