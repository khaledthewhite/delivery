using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DeliveryManagementSystem.Data;

namespace DeliveryManagementSystem.Forms
{
    public partial class FrmOrders : Form
    {
        public FrmOrders()
        {
            InitializeComponent();
        }

        private void FrmOrders_Load(object sender, EventArgs e)
        {
            if (!this.DesignMode)
            {
                cmbOrderStatus.SelectedIndex = 0;
                LoadCustomers();
                LoadData();
            }
        }

        private void LoadCustomers()
        {
            try
            {
                string query = "SELECT name FROM customers";
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                cmbCustomer.Items.Clear();
                foreach (DataRow row in dt.Rows)
                {
                    cmbCustomer.Items.Add(row["name"].ToString());
                }
                if (cmbCustomer.Items.Count > 0)
                    cmbCustomer.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadData()
        {
            try
            {
                string query = "SELECT order_id AS [رقم الطلب], customer_name AS [العميل], order_date AS [تاريخ الطلب], pickup_location AS [مكان الاستلام], delivery_location AS [مكان التسليم], cost AS [التكلفة], status AS [الحالة] FROM orders";
                dgvOrders.DataSource = DatabaseHelper.ExecuteQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtOrderId.Text) || string.IsNullOrEmpty(cmbCustomer.Text))
            {
                MessageBox.Show("رقم الطلب والعميل مطلوبان", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "INSERT INTO orders (order_id, customer_name, order_date, pickup_location, delivery_location, cost, status) VALUES (@Id, @Customer, @Date, @Pickup, @Delivery, @Cost, @Status)";
                SqlParameter[] parameters = {
                    new SqlParameter("@Id", txtOrderId.Text),
                    new SqlParameter("@Customer", cmbCustomer.Text),
                    new SqlParameter("@Date", dtpOrderDate.Text),
                    new SqlParameter("@Pickup", txtPickupAddress.Text),
                    new SqlParameter("@Delivery", txtDeliveryAddress.Text),
                    new SqlParameter("@Cost", string.IsNullOrEmpty(txtDeliveryCost.Text) ? "0" : txtDeliveryCost.Text),
                    new SqlParameter("@Status", cmbOrderStatus.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtOrderId.Text))
            {
                MessageBox.Show("الرجاء تحديد طلب لتعديله", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "UPDATE orders SET customer_name=@Customer, order_date=@Date, pickup_location=@Pickup, delivery_location=@Delivery, cost=@Cost, status=@Status WHERE order_id=@Id";
                SqlParameter[] parameters = {
                    new SqlParameter("@Id", txtOrderId.Text),
                    new SqlParameter("@Customer", cmbCustomer.Text),
                    new SqlParameter("@Date", dtpOrderDate.Text),
                    new SqlParameter("@Pickup", txtPickupAddress.Text),
                    new SqlParameter("@Delivery", txtDeliveryAddress.Text),
                    new SqlParameter("@Cost", string.IsNullOrEmpty(txtDeliveryCost.Text) ? "0" : txtDeliveryCost.Text),
                    new SqlParameter("@Status", cmbOrderStatus.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtOrderId.Text))
            {
                MessageBox.Show("الرجاء تحديد طلب لحذفه", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("هل أنت متأكد من حذف هذا السجل؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM orders WHERE order_id=@Id";
                    SqlParameter[] parameters = { new SqlParameter("@Id", txtOrderId.Text) };
                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                    btnClear_Click(null, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtOrderId.Clear();
            if (cmbCustomer.Items.Count > 0) cmbCustomer.SelectedIndex = 0;
            dtpOrderDate.Value = DateTime.Now;
            txtPickupAddress.Clear();
            txtDeliveryAddress.Clear();
            txtDeliveryCost.Clear();
            cmbOrderStatus.SelectedIndex = 0;
            txtSearchOrder.Clear();
            txtOrderId.Focus();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT order_id AS [رقم الطلب], customer_name AS [العميل], order_date AS [تاريخ الطلب], pickup_location AS [مكان الاستلام], delivery_location AS [مكان التسليم], cost AS [التكلفة], status AS [الحالة] FROM orders WHERE customer_name LIKE @Search OR order_id LIKE @Search";
                SqlParameter[] parameters = { new SqlParameter("@Search", "%" + txtSearchOrder.Text + "%") };
                dgvOrders.DataSource = DatabaseHelper.ExecuteQuery(query, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvOrders_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvOrders.Rows[e.RowIndex];
                txtOrderId.Text = row.Cells["رقم الطلب"].Value.ToString();
                cmbCustomer.Text = row.Cells["العميل"].Value.ToString();
                try { dtpOrderDate.Value = Convert.ToDateTime(row.Cells["تاريخ الطلب"].Value); } catch { }
                txtPickupAddress.Text = row.Cells["مكان الاستلام"].Value.ToString();
                txtDeliveryAddress.Text = row.Cells["مكان التسليم"].Value.ToString();
                txtDeliveryCost.Text = row.Cells["التكلفة"].Value.ToString();
                cmbOrderStatus.Text = row.Cells["الحالة"].Value.ToString();
            }
        }
    }
}
