using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DeliveryManagementSystem.Data;

namespace DeliveryManagementSystem.Forms
{
    public partial class FrmDeliveries : Form
    {
        public FrmDeliveries()
        {
            InitializeComponent();
        }

        private void FrmDeliveries_Load(object sender, EventArgs e)
        {
            if (!this.DesignMode)
            {
                cmbDeliveryStatus.SelectedIndex = 0;
                LoadCombos();
                LoadData();
            }
        }

        private void LoadCombos()
        {
            try
            {
                // Load Orders
                DataTable dtOrders = DatabaseHelper.ExecuteQuery("SELECT CONCAT('طلب #', order_id, ' - ', customer_name) AS order_info FROM orders");
                cmbOrder.Items.Clear();
                foreach (DataRow row in dtOrders.Rows)
                    cmbOrder.Items.Add(row["order_info"].ToString());
                if (cmbOrder.Items.Count > 0) cmbOrder.SelectedIndex = 0;

                // Load Couriers
                DataTable dtCouriers = DatabaseHelper.ExecuteQuery("SELECT name FROM couriers");
                cmbCourier.Items.Clear();
                foreach (DataRow row in dtCouriers.Rows)
                    cmbCourier.Items.Add(row["name"].ToString());
                if (cmbCourier.Items.Count > 0) cmbCourier.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadData()
        {
            try
            {
                string query = "SELECT delivery_id AS [رقم التوصيل], order_info AS [رقم الطلب], courier_name AS [المندوب], delivery_date AS [تاريخ التوصيل], delivery_status AS [الحالة] FROM deliveries";
                dgvDeliveries.DataSource = DatabaseHelper.ExecuteQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cmbOrder.Text) || string.IsNullOrEmpty(cmbCourier.Text))
            {
                MessageBox.Show("الطلب والمندوب مطلوبان", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "INSERT INTO deliveries (order_info, courier_name, delivery_date, delivery_status) VALUES (@Order, @Courier, @Date, @Status)";
                SqlParameter[] parameters = {
                    new SqlParameter("@Order", cmbOrder.Text),
                    new SqlParameter("@Courier", cmbCourier.Text),
                    new SqlParameter("@Date", dtpDeliveryDate.Text),
                    new SqlParameter("@Status", cmbDeliveryStatus.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtDeliveryId.Text))
            {
                MessageBox.Show("الرجاء تحديد توصيل لتعديله", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "UPDATE deliveries SET order_info=@Order, courier_name=@Courier, delivery_date=@Date, delivery_status=@Status WHERE delivery_id=@Id";
                SqlParameter[] parameters = {
                    new SqlParameter("@Id", txtDeliveryId.Text),
                    new SqlParameter("@Order", cmbOrder.Text),
                    new SqlParameter("@Courier", cmbCourier.Text),
                    new SqlParameter("@Date", dtpDeliveryDate.Text),
                    new SqlParameter("@Status", cmbDeliveryStatus.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtDeliveryId.Text))
            {
                MessageBox.Show("الرجاء تحديد توصيل لحذفه", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("هل أنت متأكد من حذف هذا السجل؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM deliveries WHERE delivery_id=@Id";
                    SqlParameter[] parameters = { new SqlParameter("@Id", txtDeliveryId.Text) };
                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                    btnClear_Click(null, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDeliveryId.Clear();
            if (cmbOrder.Items.Count > 0) cmbOrder.SelectedIndex = 0;
            if (cmbCourier.Items.Count > 0) cmbCourier.SelectedIndex = 0;
            dtpDeliveryDate.Value = DateTime.Now;
            cmbDeliveryStatus.SelectedIndex = 0;
            txtSearchDelivery.Clear();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT delivery_id AS [رقم التوصيل], order_info AS [رقم الطلب], courier_name AS [المندوب], delivery_date AS [تاريخ التوصيل], delivery_status AS [الحالة] FROM deliveries WHERE order_info LIKE @Search OR courier_name LIKE @Search";
                SqlParameter[] parameters = { new SqlParameter("@Search", "%" + txtSearchDelivery.Text + "%") };
                dgvDeliveries.DataSource = DatabaseHelper.ExecuteQuery(query, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvDeliveries_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvDeliveries.Rows[e.RowIndex];
                txtDeliveryId.Text = row.Cells["رقم التوصيل"].Value.ToString();
                cmbOrder.Text = row.Cells["رقم الطلب"].Value.ToString();
                cmbCourier.Text = row.Cells["المندوب"].Value.ToString();
                try { dtpDeliveryDate.Value = Convert.ToDateTime(row.Cells["تاريخ التوصيل"].Value); } catch { }
                cmbDeliveryStatus.Text = row.Cells["الحالة"].Value.ToString();
            }
        }
    }
}
