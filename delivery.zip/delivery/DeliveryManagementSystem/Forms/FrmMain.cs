using System;
using System.Windows.Forms;

namespace DeliveryManagementSystem.Forms
{
    public partial class FrmMain : Form
    {
        private string userRole;
        private string userFullName;

        public FrmMain(string role = "Admin", string fullName = "مدير النظام")
        {
            InitializeComponent();
            userRole = role;
            userFullName = fullName;

            if (userRole != "Admin")
            {
                btnUsers.Visible = false; // Hide users for non-admin
            }
        }

        private void OpenForm(Form frm)
        {
            frm.ShowDialog();
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            OpenForm(new FrmCustomers());
        }

        private void btnCouriers_Click(object sender, EventArgs e)
        {
            OpenForm(new FrmCouriers());
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            OpenForm(new FrmOrders());
        }

        private void btnDeliveries_Click(object sender, EventArgs e)
        {
            OpenForm(new FrmDeliveries());
        }

        private void btnPayments_Click(object sender, EventArgs e)
        {
            OpenForm(new FrmPayments());
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            OpenForm(new FrmUsers());
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            OpenForm(new FrmReports());
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmLogin login = new FrmLogin();
            login.ShowDialog();
            this.Close();
        }

        private void FrmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
