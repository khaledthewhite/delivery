using System;
using System.Data;
using System.Windows.Forms;
using DeliveryManagementSystem.Data;

namespace DeliveryManagementSystem.Forms
{
    public partial class FrmReports : Form
    {
        public FrmReports()
        {
            InitializeComponent();
        }

        private void FrmReports_Load(object sender, EventArgs e)
        {
            if (!this.DesignMode)
            {
                cmbReportType.SelectedIndex = 0;
            }
        }

        private void btnShowReport_Click(object sender, EventArgs e)
        {
            if (cmbReportType.SelectedIndex == -1) return;

            string query = "";

            switch (cmbReportType.SelectedIndex)
            {
                case 0: // تقرير العملاء
                    query = "SELECT customer_id AS [رقم العميل], name AS [اسم العميل], phone AS [رقم الهاتف], address AS [العنوان], email AS [البريد الإلكتروني] FROM customers";
                    break;
                case 1: // تقرير المندوبين
                    query = "SELECT courier_id AS [رقم المندوب], name AS [اسم المندوب], phone AS [رقم الهاتف], vehicle_type AS [نوع المركبة], license_number AS [رقم الرخصة], availability_status AS [الحالة] FROM couriers";
                    break;
                case 2: // تقرير الطلبات
                    query = "SELECT order_id AS [رقم الطلب], customer_name AS [العميل], order_date AS [تاريخ الطلب], pickup_location AS [مكان الاستلام], delivery_location AS [مكان التسليم], cost AS [التكلفة], status AS [الحالة] FROM orders";
                    break;
                case 3: // تقرير التوصيلات
                    query = "SELECT delivery_id AS [رقم التوصيل], order_info AS [رقم الطلب], courier_name AS [المندوب], delivery_date AS [تاريخ التوصيل], delivery_status AS [الحالة] FROM deliveries";
                    break;
                case 4: // تقرير المدفوعات
                    query = "SELECT payment_id AS [رقم الدفع], order_info AS [الطلب], payment_date AS [تاريخ الدفع], amount AS [المبلغ], payment_method AS [طريقة الدفع], payment_status AS [الحالة] FROM payments";
                    break;
                case 5: // تقرير المستخدمين
                    query = "SELECT user_id AS [رقم المستخدم], full_name AS [الاسم الكامل], username AS [اسم المستخدم], role AS [الصلاحية], status AS [الحالة] FROM users";
                    break;
            }

            try
            {
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                dgvReports.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
