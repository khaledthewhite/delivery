namespace DeliveryManagementSystem.Forms
{
    partial class FrmCouriers
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblCourierName = new System.Windows.Forms.Label();
            this.txtCourierName = new System.Windows.Forms.TextBox();
            this.lblCourierPhone = new System.Windows.Forms.Label();
            this.txtCourierPhone = new System.Windows.Forms.TextBox();
            this.lblVehicleType = new System.Windows.Forms.Label();
            this.txtVehicleType = new System.Windows.Forms.TextBox();
            this.lblLicenseNumber = new System.Windows.Forms.Label();
            this.txtLicenseNumber = new System.Windows.Forms.TextBox();
            this.lblAvailabilityStatus = new System.Windows.Forms.Label();
            this.cmbAvailabilityStatus = new System.Windows.Forms.ComboBox();
            this.txtCourierId = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtSearchCourier = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dgvCouriers = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCouriers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DeliveryManagementSystem.Properties.Resources.icon_couriers;
            this.pictureBox1.Location = new System.Drawing.Point(20, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(60, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(142, 23);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "إدارة المندوبين";
            // 
            // lblCourierName
            // 
            this.lblCourierName.AutoSize = true;
            this.lblCourierName.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourierName.Location = new System.Drawing.Point(630, 80);
            this.lblCourierName.Name = "lblCourierName";
            this.lblCourierName.Size = new System.Drawing.Size(91, 17);
            this.lblCourierName.TabIndex = 1;
            this.lblCourierName.Text = "اسم المندوب:";
            // 
            // txtCourierName
            // 
            this.txtCourierName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCourierName.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCourierName.Location = new System.Drawing.Point(400, 78);
            this.txtCourierName.Name = "txtCourierName";
            this.txtCourierName.Size = new System.Drawing.Size(220, 24);
            this.txtCourierName.TabIndex = 2;
            // 
            // lblCourierPhone
            // 
            this.lblCourierPhone.AutoSize = true;
            this.lblCourierPhone.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourierPhone.Location = new System.Drawing.Point(630, 120);
            this.lblCourierPhone.Name = "lblCourierPhone";
            this.lblCourierPhone.Size = new System.Drawing.Size(73, 17);
            this.lblCourierPhone.TabIndex = 3;
            this.lblCourierPhone.Text = "رقم الهاتف:";
            // 
            // txtCourierPhone
            // 
            this.txtCourierPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCourierPhone.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCourierPhone.Location = new System.Drawing.Point(400, 118);
            this.txtCourierPhone.Name = "txtCourierPhone";
            this.txtCourierPhone.Size = new System.Drawing.Size(220, 24);
            this.txtCourierPhone.TabIndex = 4;
            // 
            // lblVehicleType
            // 
            this.lblVehicleType.AutoSize = true;
            this.lblVehicleType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVehicleType.Location = new System.Drawing.Point(260, 80);
            this.lblVehicleType.Name = "lblVehicleType";
            this.lblVehicleType.Size = new System.Drawing.Size(83, 17);
            this.lblVehicleType.TabIndex = 5;
            this.lblVehicleType.Text = "نوع المركبة:";
            // 
            // txtVehicleType
            // 
            this.txtVehicleType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVehicleType.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVehicleType.Location = new System.Drawing.Point(30, 78);
            this.txtVehicleType.Name = "txtVehicleType";
            this.txtVehicleType.Size = new System.Drawing.Size(220, 24);
            this.txtVehicleType.TabIndex = 6;
            // 
            // lblLicenseNumber
            // 
            this.lblLicenseNumber.AutoSize = true;
            this.lblLicenseNumber.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLicenseNumber.Location = new System.Drawing.Point(260, 120);
            this.lblLicenseNumber.Name = "lblLicenseNumber";
            this.lblLicenseNumber.Size = new System.Drawing.Size(84, 17);
            this.lblLicenseNumber.TabIndex = 7;
            this.lblLicenseNumber.Text = "رقم الرخصة:";
            // 
            // txtLicenseNumber
            // 
            this.txtLicenseNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLicenseNumber.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLicenseNumber.Location = new System.Drawing.Point(30, 118);
            this.txtLicenseNumber.Name = "txtLicenseNumber";
            this.txtLicenseNumber.Size = new System.Drawing.Size(220, 24);
            this.txtLicenseNumber.TabIndex = 8;
            // 
            // lblAvailabilityStatus
            // 
            this.lblAvailabilityStatus.AutoSize = true;
            this.lblAvailabilityStatus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvailabilityStatus.Location = new System.Drawing.Point(630, 160);
            this.lblAvailabilityStatus.Name = "lblAvailabilityStatus";
            this.lblAvailabilityStatus.Size = new System.Drawing.Size(81, 17);
            this.lblAvailabilityStatus.TabIndex = 9;
            this.lblAvailabilityStatus.Text = "حالة التوفر:";
            // 
            // cmbAvailabilityStatus
            // 
            this.cmbAvailabilityStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAvailabilityStatus.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAvailabilityStatus.FormattingEnabled = true;
            this.cmbAvailabilityStatus.Items.AddRange(new object[] {
            "متاح",
            "مشغول",
            "غير متاح"});
            this.cmbAvailabilityStatus.Location = new System.Drawing.Point(400, 158);
            this.cmbAvailabilityStatus.Name = "cmbAvailabilityStatus";
            this.cmbAvailabilityStatus.Size = new System.Drawing.Size(220, 24);
            this.cmbAvailabilityStatus.TabIndex = 10;
            // 
            // txtCourierId
            // 
            this.txtCourierId.Location = new System.Drawing.Point(20, 50);
            this.txtCourierId.Name = "txtCourierId";
            this.txtCourierId.Visible = false;
            this.txtCourierId.Size = new System.Drawing.Size(50, 20);
            this.txtCourierId.TabIndex = 11;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(167)))), ((int)(((byte)(69)))));
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Image = global::DeliveryManagementSystem.Properties.Resources.icon_add;
            this.btnAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.Location = new System.Drawing.Point(540, 200);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 35);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.Text = "إضافة";
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(123)))), ((int)(((byte)(255)))));
            this.btnEdit.FlatAppearance.BorderSize = 0;
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdit.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.ForeColor = System.Drawing.Color.White;
            this.btnEdit.Image = global::DeliveryManagementSystem.Properties.Resources.icon_edit;
            this.btnEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdit.Location = new System.Drawing.Point(430, 200);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(100, 35);
            this.btnEdit.TabIndex = 13;
            this.btnEdit.Text = "تعديل";
            this.btnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(53)))), ((int)(((byte)(69)))));
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Image = global::DeliveryManagementSystem.Properties.Resources.icon_delete;
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.Location = new System.Drawing.Point(320, 200);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 35);
            this.btnDelete.TabIndex = 14;
            this.btnDelete.Text = "حذف";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(126)))), ((int)(((byte)(20)))));
            this.btnClear.FlatAppearance.BorderSize = 0;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Image = global::DeliveryManagementSystem.Properties.Resources.icon_clear;
            this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClear.Location = new System.Drawing.Point(210, 200);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 35);
            this.btnClear.TabIndex = 15;
            this.btnClear.Text = "مسح";
            this.btnClear.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtSearchCourier
            // 
            this.txtSearchCourier.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearchCourier.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchCourier.Location = new System.Drawing.Point(120, 248);
            this.txtSearchCourier.Name = "txtSearchCourier";
            this.txtSearchCourier.Size = new System.Drawing.Size(270, 24);
            this.txtSearchCourier.TabIndex = 16;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(92)))), ((int)(((byte)(178)))));
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.White;
            this.btnSearch.Image = global::DeliveryManagementSystem.Properties.Resources.icon_search;
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSearch.Location = new System.Drawing.Point(20, 244);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(90, 30);
            this.btnSearch.TabIndex = 17;
            this.btnSearch.Text = "بحث";
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dgvCouriers
            // 
            this.dgvCouriers.AllowUserToAddRows = false;
            this.dgvCouriers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCouriers.BackgroundColor = System.Drawing.Color.White;
            this.dgvCouriers.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvCouriers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCouriers.EnableHeadersVisualStyles = false;
            this.dgvCouriers.GridColor = System.Drawing.Color.LightGray;
            this.dgvCouriers.Location = new System.Drawing.Point(20, 290);
            this.dgvCouriers.MultiSelect = false;
            this.dgvCouriers.Name = "dgvCouriers";
            this.dgvCouriers.ReadOnly = true;
            this.dgvCouriers.RowHeadersVisible = false;
            this.dgvCouriers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCouriers.Size = new System.Drawing.Size(720, 150);
            this.dgvCouriers.TabIndex = 18;
            this.dgvCouriers.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(245, 245, 245);
            this.dgvCouriers.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(240, 240, 240);
            this.dgvCouriers.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCouriers_CellClick);
            // 
            // FrmCouriers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(760, 461);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dgvCouriers);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearchCourier);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtCourierId);
            this.Controls.Add(this.cmbAvailabilityStatus);
            this.Controls.Add(this.lblAvailabilityStatus);
            this.Controls.Add(this.txtLicenseNumber);
            this.Controls.Add(this.lblLicenseNumber);
            this.Controls.Add(this.txtVehicleType);
            this.Controls.Add(this.lblVehicleType);
            this.Controls.Add(this.txtCourierPhone);
            this.Controls.Add(this.lblCourierPhone);
            this.Controls.Add(this.txtCourierName);
            this.Controls.Add(this.lblCourierName);
            this.Controls.Add(this.lblTitle);
            this.Name = "FrmCouriers";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "إدارة المندوبين";
            this.Load += new System.EventHandler(this.FrmCouriers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCouriers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblCourierName;
        private System.Windows.Forms.TextBox txtCourierName;
        private System.Windows.Forms.Label lblCourierPhone;
        private System.Windows.Forms.TextBox txtCourierPhone;
        private System.Windows.Forms.Label lblVehicleType;
        private System.Windows.Forms.TextBox txtVehicleType;
        private System.Windows.Forms.Label lblLicenseNumber;
        private System.Windows.Forms.TextBox txtLicenseNumber;
        private System.Windows.Forms.Label lblAvailabilityStatus;
        private System.Windows.Forms.ComboBox cmbAvailabilityStatus;
        private System.Windows.Forms.TextBox txtCourierId;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtSearchCourier;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dgvCouriers;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
