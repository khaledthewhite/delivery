using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DeliveryManagementSystem.Data;

namespace DeliveryManagementSystem.Forms
{
    public partial class FrmCustomers : Form
    {
        public FrmCustomers()
        {
            InitializeComponent();
        }

        private void FrmCustomers_Load(object sender, EventArgs e)
        {
            if (!this.DesignMode)
            {
                LoadData();
            }
        }

        private void LoadData()
        {
            try
            {
                string query = "SELECT customer_id AS [رقم العميل], name AS [اسم العميل], phone AS [رقم الهاتف], address AS [العنوان], email AS [البريد الإلكتروني] FROM customers";
                dgvCustomers.DataSource = DatabaseHelper.ExecuteQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCustomerName.Text))
            {
                MessageBox.Show("اسم العميل مطلوب", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "INSERT INTO customers (name, phone, address, email) VALUES (@Name, @Phone, @Address, @Email)";
                SqlParameter[] parameters = {
                    new SqlParameter("@Name", txtCustomerName.Text),
                    new SqlParameter("@Phone", txtPhoneNumber.Text),
                    new SqlParameter("@Address", txtAddress.Text),
                    new SqlParameter("@Email", txtEmail.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCustomerId.Text))
            {
                MessageBox.Show("الرجاء تحديد عميل لتعديله", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "UPDATE customers SET name=@Name, phone=@Phone, address=@Address, email=@Email WHERE customer_id=@Id";
                SqlParameter[] parameters = {
                    new SqlParameter("@Id", txtCustomerId.Text),
                    new SqlParameter("@Name", txtCustomerName.Text),
                    new SqlParameter("@Phone", txtPhoneNumber.Text),
                    new SqlParameter("@Address", txtAddress.Text),
                    new SqlParameter("@Email", txtEmail.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCustomerId.Text))
            {
                MessageBox.Show("الرجاء تحديد عميل لحذفه", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("هل أنت متأكد من حذف هذا السجل؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM customers WHERE customer_id=@Id";
                    SqlParameter[] parameters = { new SqlParameter("@Id", txtCustomerId.Text) };
                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                    btnClear_Click(null, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCustomerId.Clear();
            txtCustomerName.Clear();
            txtPhoneNumber.Clear();
            txtAddress.Clear();
            txtEmail.Clear();
            txtSearchCustomer.Clear();
            txtCustomerName.Focus();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT customer_id AS [رقم العميل], name AS [اسم العميل], phone AS [رقم الهاتف], address AS [العنوان], email AS [البريد الإلكتروني] FROM customers WHERE name LIKE @Search OR phone LIKE @Search";
                SqlParameter[] parameters = { new SqlParameter("@Search", "%" + txtSearchCustomer.Text + "%") };
                dgvCustomers.DataSource = DatabaseHelper.ExecuteQuery(query, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvCustomers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvCustomers.Rows[e.RowIndex];
                txtCustomerId.Text = row.Cells["رقم العميل"].Value.ToString();
                txtCustomerName.Text = row.Cells["اسم العميل"].Value.ToString();
                txtPhoneNumber.Text = row.Cells["رقم الهاتف"].Value.ToString();
                txtAddress.Text = row.Cells["العنوان"].Value.ToString();
                txtEmail.Text = row.Cells["البريد الإلكتروني"].Value.ToString();
            }
        }
    }
}
