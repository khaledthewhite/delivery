using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DeliveryManagementSystem.Data;

namespace DeliveryManagementSystem.Forms
{
    public partial class FrmUsers : Form
    {
        public FrmUsers()
        {
            InitializeComponent();
        }

        private void FrmUsers_Load(object sender, EventArgs e)
        {
            if (!this.DesignMode)
            {
                cmbRole.SelectedIndex = 0;
                cmbStatus.SelectedIndex = 0;
                LoadData();
            }
        }

        private void LoadData()
        {
            try
            {
                string query = "SELECT user_id AS [رقم المستخدم], full_name AS [الاسم الكامل], username AS [اسم المستخدم], password AS [كلمة المرور], role AS [الصلاحية], status AS [الحالة] FROM users";
                dgvUsers.DataSource = DatabaseHelper.ExecuteQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("اسم المستخدم وكلمة المرور مطلوبان", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "INSERT INTO users (full_name, username, password, role, status) VALUES (@FullName, @Username, @Password, @Role, @Status)";
                SqlParameter[] parameters = {
                    new SqlParameter("@FullName", txtFullName.Text),
                    new SqlParameter("@Username", txtUsername.Text),
                    new SqlParameter("@Password", txtPassword.Text),
                    new SqlParameter("@Role", cmbRole.Text),
                    new SqlParameter("@Status", cmbStatus.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUserId.Text))
            {
                MessageBox.Show("الرجاء تحديد مستخدم لتعديله", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "UPDATE users SET full_name=@FullName, username=@Username, password=@Password, role=@Role, status=@Status WHERE user_id=@Id";
                SqlParameter[] parameters = {
                    new SqlParameter("@Id", txtUserId.Text),
                    new SqlParameter("@FullName", txtFullName.Text),
                    new SqlParameter("@Username", txtUsername.Text),
                    new SqlParameter("@Password", txtPassword.Text),
                    new SqlParameter("@Role", cmbRole.Text),
                    new SqlParameter("@Status", cmbStatus.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUserId.Text))
            {
                MessageBox.Show("الرجاء تحديد مستخدم لحذفه", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("هل أنت متأكد من حذف هذا السجل؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM users WHERE user_id=@Id";
                    SqlParameter[] parameters = { new SqlParameter("@Id", txtUserId.Text) };
                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                    btnClear_Click(null, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtUserId.Clear();
            txtFullName.Clear();
            txtUsername.Clear();
            txtPassword.Clear();
            cmbRole.SelectedIndex = 0;
            cmbStatus.SelectedIndex = 0;
            txtSearchUser.Clear();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT user_id AS [رقم المستخدم], full_name AS [الاسم الكامل], username AS [اسم المستخدم], password AS [كلمة المرور], role AS [الصلاحية], status AS [الحالة] FROM users WHERE full_name LIKE @Search OR username LIKE @Search";
                SqlParameter[] parameters = { new SqlParameter("@Search", "%" + txtSearchUser.Text + "%") };
                dgvUsers.DataSource = DatabaseHelper.ExecuteQuery(query, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvUsers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvUsers.Rows[e.RowIndex];
                txtUserId.Text = row.Cells["رقم المستخدم"].Value.ToString();
                txtFullName.Text = row.Cells["الاسم الكامل"].Value.ToString();
                txtUsername.Text = row.Cells["اسم المستخدم"].Value.ToString();
                txtPassword.Text = row.Cells["كلمة المرور"].Value.ToString();
                cmbRole.Text = row.Cells["الصلاحية"].Value.ToString();
                cmbStatus.Text = row.Cells["الحالة"].Value.ToString();
            }
        }
    }
}
