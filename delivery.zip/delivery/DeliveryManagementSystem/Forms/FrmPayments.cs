using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DeliveryManagementSystem.Data;

namespace DeliveryManagementSystem.Forms
{
    public partial class FrmPayments : Form
    {
        public FrmPayments()
        {
            InitializeComponent();
        }

        private void FrmPayments_Load(object sender, EventArgs e)
        {
            if (!this.DesignMode)
            {
                cmbPaymentMethod.SelectedIndex = 0;
                cmbPaymentStatus.SelectedIndex = 0;
                LoadOrders();
                LoadData();
            }
        }

        private void LoadOrders()
        {
            try
            {
                DataTable dtOrders = DatabaseHelper.ExecuteQuery("SELECT CONCAT('طلب #', order_id, ' - ', customer_name) AS order_info FROM orders");
                cmbPaymentOrder.Items.Clear();
                foreach (DataRow row in dtOrders.Rows)
                    cmbPaymentOrder.Items.Add(row["order_info"].ToString());
                if (cmbPaymentOrder.Items.Count > 0) cmbPaymentOrder.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadData()
        {
            try
            {
                string query = "SELECT payment_id AS [رقم الدفع], order_info AS [الطلب], payment_date AS [تاريخ الدفع], amount AS [المبلغ], payment_method AS [طريقة الدفع], payment_status AS [الحالة] FROM payments";
                dgvPayments.DataSource = DatabaseHelper.ExecuteQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cmbPaymentOrder.Text) || string.IsNullOrEmpty(txtAmount.Text))
            {
                MessageBox.Show("الطلب والمبلغ مطلوبان", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "INSERT INTO payments (order_info, payment_date, amount, payment_method, payment_status) VALUES (@Order, @Date, @Amount, @Method, @Status)";
                SqlParameter[] parameters = {
                    new SqlParameter("@Order", cmbPaymentOrder.Text),
                    new SqlParameter("@Date", dtpPaymentDate.Text),
                    new SqlParameter("@Amount", txtAmount.Text),
                    new SqlParameter("@Method", cmbPaymentMethod.Text),
                    new SqlParameter("@Status", cmbPaymentStatus.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPaymentId.Text))
            {
                MessageBox.Show("الرجاء تحديد دفعة لتعديلها", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = "UPDATE payments SET order_info=@Order, payment_date=@Date, amount=@Amount, payment_method=@Method, payment_status=@Status WHERE payment_id=@Id";
                SqlParameter[] parameters = {
                    new SqlParameter("@Id", txtPaymentId.Text),
                    new SqlParameter("@Order", cmbPaymentOrder.Text),
                    new SqlParameter("@Date", dtpPaymentDate.Text),
                    new SqlParameter("@Amount", txtAmount.Text),
                    new SqlParameter("@Method", cmbPaymentMethod.Text),
                    new SqlParameter("@Status", cmbPaymentStatus.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
                btnClear_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPaymentId.Text))
            {
                MessageBox.Show("الرجاء تحديد دفعة لحذفها", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("هل أنت متأكد من حذف هذا السجل؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM payments WHERE payment_id=@Id";
                    SqlParameter[] parameters = { new SqlParameter("@Id", txtPaymentId.Text) };
                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    MessageBox.Show("تمت العملية بنجاح", "نجاح", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                    btnClear_Click(null, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPaymentId.Clear();
            if (cmbPaymentOrder.Items.Count > 0) cmbPaymentOrder.SelectedIndex = 0;
            dtpPaymentDate.Value = DateTime.Now;
            txtAmount.Clear();
            cmbPaymentMethod.SelectedIndex = 0;
            cmbPaymentStatus.SelectedIndex = 0;
            txtSearchPayment.Clear();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT payment_id AS [رقم الدفع], order_info AS [الطلب], payment_date AS [تاريخ الدفع], amount AS [المبلغ], payment_method AS [طريقة الدفع], payment_status AS [الحالة] FROM payments WHERE order_info LIKE @Search";
                SqlParameter[] parameters = { new SqlParameter("@Search", "%" + txtSearchPayment.Text + "%") };
                dgvPayments.DataSource = DatabaseHelper.ExecuteQuery(query, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvPayments_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvPayments.Rows[e.RowIndex];
                txtPaymentId.Text = row.Cells["رقم الدفع"].Value.ToString();
                cmbPaymentOrder.Text = row.Cells["الطلب"].Value.ToString();
                try { dtpPaymentDate.Value = Convert.ToDateTime(row.Cells["تاريخ الدفع"].Value); } catch { }
                txtAmount.Text = row.Cells["المبلغ"].Value.ToString();
                cmbPaymentMethod.Text = row.Cells["طريقة الدفع"].Value.ToString();
                cmbPaymentStatus.Text = row.Cells["الحالة"].Value.ToString();
            }
        }
    }
}
