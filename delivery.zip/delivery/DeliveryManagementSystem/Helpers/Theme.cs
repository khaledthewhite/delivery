using System.Drawing;

namespace DeliveryManagementSystem.Helpers
{
    public static class Theme
    {
        // Colors extracted from the reference image
        public static readonly Color SidebarColor = Color.FromArgb(30, 50, 75);
        public static readonly Color SidebarHighlight = Color.FromArgb(0, 122, 204);
        public static readonly Color ButtonAdd = Color.FromArgb(40, 167, 69);
        public static readonly Color ButtonEdit = Color.FromArgb(0, 123, 255);
        public static readonly Color ButtonDelete = Color.FromArgb(220, 53, 69);
        public static readonly Color ButtonClear = Color.FromArgb(253, 126, 20);
        public static readonly Color ButtonSearch = Color.FromArgb(0, 92, 178);
        public static readonly Color BackgroundColor = Color.White;
        public static readonly Color TextColor = Color.FromArgb(45, 45, 45);
        public static readonly Color GridHeaderColor = Color.FromArgb(240, 240, 240);
        
        // Fonts
        public static readonly Font FontTitle = new Font("Tahoma", 14F, FontStyle.Bold);
        public static readonly Font FontRegular = new Font("Tahoma", 10F, FontStyle.Regular);
        public static readonly Font FontButton = new Font("Tahoma", 10F, FontStyle.Bold);
    }
}
