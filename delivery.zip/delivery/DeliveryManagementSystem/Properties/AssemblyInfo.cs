using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DeliveryManagementSystem")]
[assembly: AssemblyDescription("نظام إدارة التوصيلات")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("DeliveryManagementSystem")]
[assembly: AssemblyCopyright("Copyright ©  2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("a8a7a6a5-a4a3-a2a1-a0a9-a8a7a6a5a4a3")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
